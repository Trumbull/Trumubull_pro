algo=`cat pools.conf | jq ".algo" --raw-output`
url=`cat pools.conf | jq ".pools[] .url" --raw-output`
user=`cat pools.conf | jq ".pools[] .user" --raw-output`
./CryptoDredge -a ${algo} -o ${url} -u ${user}
