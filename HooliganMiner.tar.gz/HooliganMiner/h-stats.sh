
#######################
# Functions
#######################

get_cards_hashes(){
	hs=''	

	#let hs=$h/$GPU_COUNT_NVIDIA
		for (( i=0; i < ${GPU_COUNT_NVIDIA}; i++ )); do
		local s=`cat $LOG_NAME| tail -n 20 | cut -c 11-14 |tail -n 1 | awk '{printf "%.0f\n",$1}'`
		local t=0
		let t=$s/$GPU_COUNT_NVIDIA
		hs[$i]=$t
	done
}

get_total_hashes(){
	local Total=`cat $LOG_NAME| tail -n 20 | cut -c 11-14 |tail -n 1 | awk '{printf "%.0f\n",$1*1000}'`
	echo $Total
}

get_nvidia_cards_temp(){
	echo $(jq -c "[.temp$nvidia_indexes_array]" <<< $gpu_stats)
}

get_nvidia_cards_fan(){
	echo $(jq -c "[.fan$nvidia_indexes_array]" <<< $gpu_stats)
}


#######################
# MAIN script body
#######################
. /hive/custom/HooliganMiner/h-manifest.conf
LOG_NAME="$CUSTOM_LOG_BASENAME.log"

khs=0


[[ -z $GPU_COUNT_NVIDIA ]] &&
	GPU_COUNT_NVIDIA=`gpu-detect NVIDIA`

#GPU stats
gpu_detect_json=`gpu-detect listjson`
nvidia_indexes_array=`echo "$gpu_detect_json" | jq -c '[ . | to_entries[] | select(.value.brand == "nvidia") | .key ]'`
gpu_stats=`timeout -s9 60 gpu-stats`

# Calc log freshness


#hs=$(get_cards_hashes)
#temp=$(get_nvidia_cards_temp)	# cards temp
#fan=$(get_nvidia_cards_fan)	# cards fan
#hs_units='khs'				    # cards temp
#khs=`echo $stats_raw | jq 'MH/s' | awk '{print $1*1000}'`
#hs=`echo $stats_raw | jq -r '.stats.hs'`
#algo='sha224'	 # algo

#stats_raw=`cat /var/log/miner/HooliganMiner/HooliganMiner.log | sed 's/\"\[/\[/' | sed 's/\]\"/\]/'`
	n=`cat $LOG_NAME | tail -n 20 | grep -n "MH/s" $LOG_NAME | awk '{print $1}'`
	nt=`echo $n | awk '{ printf("%.f",$1) }'`
	temp=$(get_nvidia_cards_temp)
	fan=$(get_nvidia_cards_fan)
	hs=
	get_cards_hashes
	hs_units='khs'
	algo='sha224'
	uptime=20
	ac='0'
	rj='0'	
	stats=$(jq -nc \
				--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
				--arg hs_units "$hs_units" \
				--argjson temp "$temp" \
				--argjson fan "$fan" \
				--arg uptime "$uptime" \
				--arg ac $ac --arg rj "$rj" \
				--arg algo "$algo" \
				'{$hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo}')
	khs=$(get_total_hashes)

# debug output
#echo temp:  $temp
#echo fan:   $fan
#echo hs:    $hs
#echo nt:  $nt
#echo stats: $stats
#echo khs:   $khs